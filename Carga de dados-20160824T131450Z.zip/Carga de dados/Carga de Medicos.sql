INSERT INTO MEDICO(cd_medi,nu_cr_medi,cd_agenda,cd_pess) VALUES(1,'21.658',1,20);
INSERT INTO MEDICO(cd_medi,nu_cr_medi,cd_agenda,cd_pess) VALUES(2,'52.45699',2,35);
INSERT INTO MEDICO(cd_medi,nu_cr_medi,cd_agenda,cd_pess) VALUES(3,'56559',3,45);