INSERT INTO AGENDA(cd_agenda,nu_hr_in_agenda,nu_hr_fi_agenda,cd_medico) VALUES(1,'8:45','16:40',1);
INSERT INTO AGENDA(cd_agenda,nu_hr_in_agenda,nu_hr_fi_agenda,cd_medico) VALUES(2,'10:00','18:00',2);
INSERT INTO AGENDA(cd_agenda,nu_hr_in_agenda,nu_hr_fi_agenda,cd_medico) VALUES(3,'12:00','17:00',3);